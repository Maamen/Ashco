// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'serializers.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializers _$serializers = (new Serializers().toBuilder()
      ..add(CommentsRecord.serializer)
      ..add(GroupsRecord.serializer)
      ..add(PostsRecord.serializer)
      ..add(UsersRecord.serializer)
      ..addBuilderFactory(
          const FullType(BuiltList, const [const FullType(DateTime)]),
          () => new ListBuilder<DateTime>()))
    .build();

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
